from .mazegen import MazeGenerator


all = [MazeGenerator]
